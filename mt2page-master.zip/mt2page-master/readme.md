# Pagină simplă înregistrare
Pagină simplă de înregistrare pentru servere de metin2.

În fișierul define.php puteți configura mesajele afișate pe pagină.
Fișierul config.php include explicația pentru conectarea la baza de date.

(c) Hunger aka Criminus 2022

![alt text](http://i.epvpimg.com/rkWIaab.png)
